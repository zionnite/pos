<div class="main-body">
	<div class="page-wrapper">

		<div class="page-body">
			<div class="row">
				<!-- task, page, download counter  start -->
			
				<div class="col-xl-6 col-md-6">
					<a href="<?php echo base_url();?>Sales_rep" style="color:white;">
					<div class="card social-card bg-simple-c-blue">
						<div class="card-block">
							<div class="row align-items-center">
								<div class="col-auto">
									<i class="fa fa-cart-plus f-34 text-c-blue social-icon"></i>
								</div>
								<div class="col">
									<h3 class="m-b-0">New</h3>
									<p>Transaction</p>
									
								</div>
							</div>
						</div>
						<a href="<?php echo base_url();?>Sales_rep" class="download-icon"><i class="feather icon-arrow-down"></i></a>
					</div>
					</a>
				</div>
				
				<div class="col-xl-6 col-md-6">
					<a href="<?php echo base_url();?>Transaction_history" style="color:white;">
					<div class="card social-card bg-simple-c-pink">
						<div class="card-block">
							<div class="row align-items-center">
								<div class="col-auto">
									<i class="fa fa-sort-amount-up-alt f-34 text-c-pink social-icon"></i>
								</div>
								<div class="col">
									<h3 class="m-b-0">History</h3>
									<p>Transaction History</p>
									
								</div>
							</div>
						</div>
						<a href="<?php echo base_url();?>Transaction_history" class="download-icon"><i class="feather icon-arrow-down"></i></a>
					</div>
					</a>
				</div>
				<!-- social download  end -->

			</div>
		</div>
	</div>

</div>
