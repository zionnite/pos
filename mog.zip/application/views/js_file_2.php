<script type="text/javascript" src="<?php echo base_url();?>files/bower_components/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files/bower_components/jquery-ui/jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files/bower_components/popper.js/dist/umd/popper.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- jquery slimscroll js -->
    <script type="text/javascript" src="<?php echo base_url();?>files/bower_components/jquery-slimscroll/jquery.slimscroll.js"></script>
    <!-- modernizr js -->
    <script type="text/javascript" src="<?php echo base_url();?>files/bower_components/modernizr/modernizr.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files/bower_components/modernizr/feature-detects/css-scrollbars.js"></script>


    <!-- i18next.min.js -->
    <script type="text/javascript" src="<?php echo base_url();?>files/bower_components/i18next/i18next.min.js"></script>
    <script type="text/javascript"
        src="<?php echo base_url();?>files/bower_components/i18next-xhr-backend/i18nextXHRBackend.min.js"></script>
    <script type="text/javascript"
        src="<?php echo base_url();?>files/bower_components/i18next-browser-languagedetector/i18nextBrowserLanguageDetector.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files/bower_components/jquery-i18next/jquery-i18next.min.js"></script>
    <!--Forms - Wizard js-->
    <script src="<?php echo base_url();?>files/bower_components/jquery.cookie/jquery.cookie.js"></script>
    <script src="<?php echo base_url();?>files/bower_components/jquery.steps/build/jquery.steps.js"></script>
    <script src="<?php echo base_url();?>files/bower_components/jquery-validation/dist/jquery.validate.js"></script>
    <!-- Validation js -->
    <script src="../../../cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js"></script>
    <script src="../../../cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files/assets/pages/form-validation/validate.js"></script>
    <!-- Custom js -->
    <script src="<?php echo base_url();?>files/assets/pages/forms-wizard-validation/form-wizard.js"></script>
    <script src="<?php echo base_url();?>files/assets/js/pcoded.min.js"></script>
    <script src="<?php echo base_url();?>files/assets/js/vartical-layout.min.js"></script>
    <script src="<?php echo base_url();?>files/assets/js/jquery.mCustomScrollbar.concat.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files/assets/js/script.js"></script>


    <script type="text/javascript" src="<?php echo base_url();?>files/bower_components/bootstrap-tagsinput/dist/bootstrap-tagsinput.js"></script>

    <!-- sweet alert js -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>files/assets/js/modal.js"></script> 
    <!-- sweet alert modal.js intialize js -->

    
    <script>
    $(document).ready(function() {
        $('#summernote').summernote();
    });
  </script>