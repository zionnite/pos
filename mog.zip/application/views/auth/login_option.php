<section class="login-block">
	<!-- Container-fluid starts -->
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<!-- Authentication card start -->


				<div class=" card">
					<div class="card-block">
						<div class="row m-b-20">
							<div class="col-md-12">
								<h3 class="text-center">Session Expired</h3>
								<p style="text-align:center;">Please login via your Link or click on your Terminal Link!</p>
								<div style="text-align:center;">
									<a href="<?php echo base_url();?>Login/sales_login">Staff Login</a>||
									<a href="<?php echo base_url();?>Login/manager_login">Manager Login</a>||
									<a href="<?php echo base_url();?>Login/owner">Store Owner Login</a>||
									<a href="<?php echo base_url();?>Login/admin">Admin Login</a>
								</div>


							</div>
						</div>
					</div>
				</div>
				<!-- end of form -->
			</div>
			<!-- end of col-sm-12 -->
		</div>
		<!-- end of row -->
	</div>
	<!-- end of container-fluid -->
</section>
