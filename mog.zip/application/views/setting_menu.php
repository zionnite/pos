
<div class="main-body">
	<div class="page-wrapper">

		<div class="page-body">
			<div class="row">           
				
                <div class="col-md-12" id="">
					<div class="card" id="">			
						<div class="card-block">
							<div class="row">
                                <div class="col-sm-6 col-md-6">
                                    <a href="<?php echo base_url();?>Dashboard/site_details" class="btn btn-danger btn-block"><i class="fa fa-chalkboard-teacher"></i> Site Details</a>
                                </div>
                                <div class="col-sm-6 col-md-6">
                                    <a href="<?php echo base_url();?>Dashboard/set_payment_api" class="btn btn-inverse btn-block"><i class="fa fa-money-check"></i>    Set Payment API</a>
                                </div>
                            </div>
						</div>
					</div>

				</div>

			</div>
		</div>
	</div>

	<div id="styleSelector">

	</div>
</div>







