<?php
class My_Model extends CI_Model{
	public $model;
	public $model_2;
	public function __construct(){
		parent::__construct();
		//$this->model	='estate/action';
		//$this->model_2	='social_model/action';
	}
}
?>